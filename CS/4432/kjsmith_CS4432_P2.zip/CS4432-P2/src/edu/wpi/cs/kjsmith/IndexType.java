package edu.wpi.cs.kjsmith;

public enum IndexType {
	Hash,
	Array
}
